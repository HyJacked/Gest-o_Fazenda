const sequelize = require('../config/database');
const UserModel = require('./user');
const AnimalModel = require('./animal');
const FeedModel = require('./feed');
const MovementModel = require('./movement');
const PhotoModel = require('./photo');

const User = UserModel(sequelize);
const Animal = AnimalModel(sequelize);
const Feed = FeedModel(sequelize);
const Movement = MovementModel(sequelize);
const Photo = PhotoModel(sequelize);

module.exports = { sequelize, User, Animal, Feed, Movement, Photo };
