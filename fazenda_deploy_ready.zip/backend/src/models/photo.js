const { DataTypes } = require('sequelize');
module.exports = (sequelize) => sequelize.define('Photo', {
  id:{type:DataTypes.INTEGER, primaryKey:true, autoIncrement:true},
  section:{type:DataTypes.STRING, allowNull:false},
  filename:{type:DataTypes.STRING, allowNull:false},
  url:{type:DataTypes.STRING, allowNull:false}
},{ tableName:'photos' });
