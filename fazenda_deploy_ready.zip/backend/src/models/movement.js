const { DataTypes } = require('sequelize');
module.exports = (sequelize) => sequelize.define('Movement', {
  id:{type:DataTypes.INTEGER, primaryKey:true, autoIncrement:true},
  entity:{type:DataTypes.ENUM('animal','feed'), allowNull:false},
  entityId:{type:DataTypes.INTEGER, allowNull:true},
  type:{type:DataTypes.ENUM('entrada','saida'), allowNull:false},
  qty:{type:DataTypes.FLOAT, allowNull:true},
  note:{type:DataTypes.STRING, allowNull:true}
},{ tableName:'movements' });
