const { DataTypes } = require('sequelize');
module.exports = (sequelize) => sequelize.define('Animal', {
  id:{type:DataTypes.INTEGER, primaryKey:true, autoIncrement:true},
  name:{type:DataTypes.STRING, allowNull:false},
  tag:{type:DataTypes.STRING, allowNull:false},
  weight:{type:DataTypes.FLOAT, allowNull:true},
  feedAvg:{type:DataTypes.FLOAT, allowNull:true},
  type:{type:DataTypes.STRING, allowNull:false}
},{ tableName:'animals' });
