require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const { sequelize, User } = require('./models');
const authRoutes = require('./routes/auth');
const animalRoutes = require('./routes/animals');
const feedRoutes = require('./routes/feed');
const photoRoutes = require('./routes/photos');
const dashRoutes = require('./routes/dashboard');
const bcrypt = require('bcrypt');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(process.env.UPLOAD_DIR || path.join(__dirname,'..','uploads')));

app.use('/api/auth', authRoutes);
app.use('/api/animals', animalRoutes);
app.use('/api/feed', feedRoutes);
app.use('/api/photos', photoRoutes);
app.use('/api/dashboard', dashRoutes);

async function seedAdmin(){
  const admin = await User.findOne({ where:{ username:'admin' } });
  if(!admin){
    const hash = await bcrypt.hash('admin123',10);
    await User.create({ username:'admin', passwordHash:hash, role:'admin' });
    console.log('Admin created: admin / admin123');
  }
}

(async ()=>{
  try{
    await sequelize.sync({ alter: true });
    await seedAdmin();
    const PORT = process.env.PORT || 4000;
    app.listen(PORT, ()=>console.log('Server on',PORT));
  }catch(e){
    console.error(e);
  }
})();
