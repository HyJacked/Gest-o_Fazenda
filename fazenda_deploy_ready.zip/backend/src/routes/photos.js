const express=require('express'); const router=express.Router(); const multer=require('multer'); const path=require('path'); const fs=require('fs'); const { Photo } = require('../models'); const { authMiddleware, requireRole } = require('../middleware/authJwt');
const uploadDir = path.join(process.env.UPLOAD_DIR || path.join(__dirname,'..','..','uploads'));
if(!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir,{ recursive:true });
const storage = multer.diskStorage({ destination:(req,file,cb)=>cb(null,uploadDir), filename:(req,file,cb)=>cb(null, Date.now()+'-'+file.originalname.replace(/\s+/g,'_')) });
const upload = multer({ storage });
router.post('/:section', authMiddleware, requireRole('admin'), upload.single('photo'), async (req,res)=>{ const section=req.params.section; const file=req.file; if(!file) return res.status(400).json({message:'No file'}); const url=`/uploads/${file.filename}`; const p = await Photo.create({ section, filename:file.filename, url }); res.json(p); });
router.get('/:section', authMiddleware, async (req,res)=>{ const section=req.params.section; const photos = await Photo.findAll({ where:{ section }}); res.json(photos); });
module.exports=router;
