const express=require('express'); const router=express.Router(); const { Animal, Movement } = require('../models'); const { authMiddleware, requireRole } = require('../middleware/authJwt');
router.get('/', authMiddleware, async (req,res)=>{ const animals = await Animal.findAll(); res.json(animals); });
router.post('/', authMiddleware, requireRole('admin'), async (req,res)=>{ const { name, tag, weight, feedAvg, type } = req.body; const a = await Animal.create({ name, tag, weight, feedAvg, type }); await Movement.create({ entity:'animal', entityId:a.id, type:'entrada', note:'Cadastro inicial' }); res.json(a); });
router.delete('/:id', authMiddleware, requireRole('admin'), async (req,res)=>{ const id=req.params.id; await Animal.destroy({ where:{ id }}); await Movement.create({ entity:'animal', entityId:id, type:'saida', note:'Removido' }); res.json({ok:true}); });
router.post('/:id/movement', authMiddleware, requireRole('admin'), async (req,res)=>{ const id=req.params.id; const { type, note } = req.body; const m = await Movement.create({ entity:'animal', entityId:id, type: type==='entrada'?'entrada':'saida', note }); res.json(m); });
module.exports=router;
