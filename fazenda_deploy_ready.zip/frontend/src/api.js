import axios from 'axios';
const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000';
function authHeader(){ const token = localStorage.getItem('token'); return token? { Authorization: 'Bearer '+token } : {}; }
export async function login(username,password){ const res = await axios.post(API_BASE + '/api/auth/login', { username, password }); return res.data; }
export async function getSummary(){ const res = await axios.get(API_BASE + '/api/dashboard/summary', { headers: authHeader() }); return res.data; }
export async function getAnimals(){ const res = await axios.get(API_BASE + '/api/animals', { headers: authHeader() }); return res.data; }
export async function createAnimal(payload){ const res = await axios.post(API_BASE + '/api/animals', payload, { headers: {...authHeader(), 'Content-Type': 'application/json'} }); return res.data; }
export async function getFeeds(){ const res = await axios.get(API_BASE + '/api/feed', { headers: authHeader() }); return res.data; }
export async function uploadPhoto(section,file){ const fd = new FormData(); fd.append('photo', file); const res = await axios.post(API_BASE + '/api/photos/' + section, fd, { headers: {...authHeader(), 'Content-Type': 'multipart/form-data'} }); return res.data; }
export async function getPhotos(section){ const res = await axios.get(API_BASE + '/api/photos/' + section, { headers: authHeader() }); return res.data; }
