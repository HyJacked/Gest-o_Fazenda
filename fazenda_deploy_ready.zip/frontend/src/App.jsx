import React, { useEffect, useState, useRef } from 'react';
import { login as apiLogin, getSummary, getAnimals, createAnimal, getFeeds, uploadPhoto, getPhotos } from './api';
import Chart from 'chart.js/auto';

function Login({ onLogin }){
  const [u,setU]=useState(''); const [p,setP]=useState('');
  async function sub(){ try{ const res = await apiLogin(u,p); localStorage.setItem('token', res.token); onLogin(res.user); }catch(e){ alert('Erro no login'); } }
  return (<div className='card' style={{maxWidth:360, margin:'20px auto'}}><h3>Login</h3><input className='input' placeholder='Usuário' value={u} onChange={e=>setU(e.target.value)} /><input className='input' type='password' placeholder='Senha' value={p} onChange={e=>setP(e.target.value)} /><div style={{marginTop:8}}><button className='btn' onClick={sub}>Entrar</button></div><p className='small'>Use admin/admin123</p></div>)
}

function ChartSmart({ summary }){
  const ref = useRef();
  useEffect(()=>{
    if(!summary) return;
    const labels = summary.counts.map(c=>c.type);
    const counts = summary.counts.map(c=>parseInt(c.count));
    const avgsRaw = summary.avgs.map(a=>({type:a.type,avg:parseFloat(a.avgFeed)}));
    const avgs = labels.map(l=>{ const f = avgsRaw.find(x=>x.type===l); return f? f.avg:0 });
    const ctx = ref.current.getContext('2d');
    if(window._fazendaChart) window._fazendaChart.destroy();
    window._fazendaChart = new Chart(ctx, {
      type:'bar',
      data:{ labels, datasets:[ { type:'bar', label:'Quantidade', data:counts, backgroundColor:'#4CAF50' }, { type:'line', label:'Média ração', data:avgs, borderColor:'#FFC107', yAxisID:'y1' } ] },
      options:{ responsive:true, scales:{ y:{ beginAtZero:true }, y1:{ beginAtZero:true, position:'right', grid:{ display:false } } } }
    });
  },[summary]);
  return <canvas ref={ref} style={{maxHeight:300}} />
}

export default function App(){
  const [user,setUser]=useState(null); const [summary,setSummary]=useState(null);
  const [animals,setAnimals]=useState([]); const [feeds,setFeeds]=useState([]);
  const [photos,setPhotos]=useState([]); const [file,setFile]=useState(null);

  useEffect(()=>{ const t = localStorage.getItem('token'); if(t) setUser({}); },[]);
  useEffect(()=>{ if(user) fetchAll(); },[user]);

  async function fetchAll(){ try{ const s = await getSummary(); setSummary(s); const a = await getAnimals(); setAnimals(a); const f = await getFeeds(); setFeeds(f); }catch(e){ console.error(e); } }

  function handleLogin(u){ setUser(u); fetchAll(); }

  async function submitAnimal(e){ e.preventDefault(); if(!user) return alert('Faça login'); const fd=new FormData(e.target); const payload={ name:fd.get('name'), tag:fd.get('tag'), weight:parseFloat(fd.get('weight')), feedAvg:parseFloat(fd.get('feedAvg')), type:fd.get('type') }; await createAnimal(payload); fetchAll(); e.target.reset(); }

  async function handleUpload(section){ if(!file) return alert('Selecione'); await uploadPhoto(section,file); const p = await getPhotos(section); setPhotos(p); setFile(null); }

  return (<div className='app'><div className='header'><div className='brand'>Fazenda Vale da Onça</div><div className='controls'>{user? <button className='btn' onClick={()=>{ localStorage.removeItem('token'); setUser(null); window.location.reload(); }}>Sair</button> : <span className='small'>Visitante</span>}</div></div>{!user? <Login onLogin={handleLogin}/> : (<><div className='card'><h3>Resumo</h3><div style={{display:'flex',gap:20,flexWrap:'wrap'}}><div style={{minWidth:200}}><p>Total animais: <strong>{summary? summary.counts.reduce((s,c)=>s+parseInt(c.count),0):0}</strong></p></div><div style={{flex:1}}><ChartSmart summary={summary} /></div></div></div><div className='card'><h3>Animais</h3><table className='table'><thead><tr><th>Nome</th><th>Etiqueta</th><th>Peso</th><th>Ração</th><th>Tipo</th></tr></thead><tbody>{animals.map(a=>(<tr key={a.id}><td>{a.name}</td><td>{a.tag}</td><td>{a.weight}</td><td>{a.feedAvg}</td><td>{a.type}</td></tr>))}</tbody></table><form onSubmit={submitAnimal} className='form-row' style={{marginTop:12}}><input name='name' className='input' placeholder='Nome' /><input name='tag' className='input' placeholder='Etiqueta' /><input name='weight' className='input' placeholder='Peso' /><input name='feedAvg' className='input' placeholder='Ração média' /><select name='type' className='input'><option>Bovino</option><option>Equino</option><option>Suíno</option></select><button className='btn' type='submit'>Adicionar</button></form></div><div className='card'><h3>Ração</h3><table className='table'><thead><tr><th>Nome</th><th>Qtd</th></tr></thead><tbody>{feeds.map(f=>(<tr key={f.id}><td>{f.name}</td><td>{f.quantity}</td></tr>))}</tbody></table></div><div className='card'><h3>Galeria</h3><div style={{display:'flex',gap:8,alignItems:'center'}}><input type='file' onChange={e=>setFile(e.target.files[0])} /><button className='btn' onClick={()=>handleUpload('galeria')}>Enviar foto (admin)</button><button className='btn' onClick={async ()=>{ const p = await getPhotos('galeria'); setPhotos(p); }}>Carregar fotos</button></div><div className='photo-grid'>{photos.map(p=>(<img key={p.id} src={(import.meta.env.VITE_API_BASE||'http://localhost:4000')+p.url} alt=''/>))}</div></div></>)} </div>);
