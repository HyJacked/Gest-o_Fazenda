    # Fazendo deploy rápido (Render + Vercel) — Guia simples

1) Faça um repositório no GitHub e **push** deste projeto (ver arquivo README no zip).

2) Backend (Render):
   - Acesse https://render.com → New → Web Service → Connect repo → escolha `backend`.
   - Build command: `npm install`
   - Start command: `node src/index.js`
   - Adicione env var `JWT_SECRET` (coloque uma senha forte).
   - Crie um Postgres (Render → Databases → New) e cole a `DATABASE_URL` nas env vars do serviço.
   - Deploy. Copie a URL do backend.

3) Frontend (Vercel):
   - Acesse https://vercel.com → New Project → Import Git Repository → selecione o mesmo repo.
   - Antes de deploy, adicione env var `VITE_API_BASE` = `https://<sua-backend>.onrender.com` (a URL do backend).
   - Aponte o Root Directory para `frontend` (se solicitado).
   - Deploy.

4) Teste: abra o URL do frontend e faça login com:
   - user: `admin`
   - pass: `admin123`

Se quiser, eu posso:
- Gerar imagens/passes com prints para enviar ao seu cliente.
- Fazer o deploy eu mesmo (preciso de acesso ao repositório).

